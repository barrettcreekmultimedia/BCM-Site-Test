const motion = matchMedia('(prefers-reduced-motion: reduce)');

for (const gallery of document.querySelectorAll('[data-rotate]')) {
  const slides = [...gallery.querySelectorAll('.gallery-slide')];
  if (slides.length < 2) continue;
  let current = 0;
  slides[0].classList.add('is-current');
  gallery.classList.add('is-rotating');
  setInterval(() => {
    if (motion.matches || document.hidden) return;
    slides[current].classList.remove('is-current');
    current = (current + 1) % slides.length;
    slides[current].classList.add('is-current');
  }, 5000);
}

for (const trigger of document.querySelectorAll('[data-dialog]')) {
  const dialog = document.getElementById(trigger.dataset.dialog);
  if (!dialog) continue;
  trigger.addEventListener('click', event => {
    event.preventDefault();
    const video = dialog.querySelector('.video-frame');
    if (video) video.replaceChildren(dialog.querySelector('template').content.cloneNode(true));
    dialog.showModal();
  });
}

for (const dialog of document.querySelectorAll('dialog')) {
  dialog.querySelector('[data-close]').addEventListener('click', () => dialog.close());
  dialog.addEventListener('close', () => dialog.querySelector('.video-frame')?.replaceChildren());
}

// Reference requests stay local until a delivery destination is configured.
for (const form of document.querySelectorAll('[data-inquiry="reference"]')) {
  form.addEventListener('submit', event => {
    event.preventDefault();
    const status = form.querySelector('.form-status');
    status.textContent = 'Form delivery is currently unavailable. Your message was not sent.';
    status.hidden = false;
  });
}

for (const button of document.querySelectorAll('.project-play')) {
  button.addEventListener('click', () => {
    const player = button.nextElementSibling.content.cloneNode(true);
    button.replaceWith(player);
  }, {once: true});
}

const photoViewer = document.querySelector('.photo-viewer');
if (photoViewer) {
  const slides = [...document.querySelectorAll('.sqs-system-gallery .slides .slide')];
  const image = photoViewer.querySelector('img');
  const caption = photoViewer.querySelector('.photo-caption');
  let current = 0;
  function showPhoto(index) {
    current = (index + slides.length) % slides.length;
    const slide = slides[current];
    const thumbnail = slide.querySelector('img');
    image.src = thumbnail.src;
    image.alt = thumbnail.alt;
    const copy = slide.querySelector('.slide-meta');
    caption.replaceChildren(...[...copy.children].map(child => child.cloneNode(true)));
    caption.hidden = !copy.textContent.trim();
  }
  slides.forEach((slide, index) => {
    const thumbnail = slide.querySelector('img');
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'photo-button';
    button.setAttribute('aria-label', thumbnail.alt || `View photo ${index + 1}`);
    thumbnail.replaceWith(button);
    button.append(thumbnail);
    button.addEventListener('click', () => {
      showPhoto(index);
      photoViewer.showModal();
    });
  });
  for (const button of photoViewer.querySelectorAll('[data-photo-step]')) {
    button.addEventListener('click', () => showPhoto(current + Number(button.dataset.photoStep)));
  }
  photoViewer.addEventListener('keydown', event => {
    if (event.key === 'ArrowLeft') showPhoto(current - 1);
    if (event.key === 'ArrowRight') showPhoto(current + 1);
  });
}
